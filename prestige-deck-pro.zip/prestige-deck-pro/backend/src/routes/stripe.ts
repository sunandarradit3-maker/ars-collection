import { Router } from 'express';
import { createCheckoutSession } from '../controllers/stripeController.js';
import { protect } from '../middleware/auth.js';

const router = Router();

router.post('/checkout', protect, createCheckoutSession);

export default router;