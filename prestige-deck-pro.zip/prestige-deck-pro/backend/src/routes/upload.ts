import { Router } from 'express';
import { uploadMedia } from '../controllers/uploadController.js';
import { protect } from '../middleware/auth.js';

const router = Router();

// Upload media (image/audio/video) to S3
router.post('/', protect, uploadMedia);

export default router;