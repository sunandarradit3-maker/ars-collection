import { Router } from 'express';
import { generateOutline, designSlides } from '../controllers/aiController.js';
import { protect } from '../middleware/auth.js';

const router = Router();

router.post('/outline', protect, generateOutline);
router.post('/design', protect, designSlides);

export default router;