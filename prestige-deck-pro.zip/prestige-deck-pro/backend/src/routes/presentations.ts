import { Router } from 'express';
import {
  getPresentations,
  createPresentation,
  getPresentation,
  updatePresentation,
  deletePresentation,
} from '../controllers/presentationController.js';
import { protect } from '../middleware/auth.js';

const router = Router();

router.get('/', protect, getPresentations);
router.post('/', protect, createPresentation);
router.get('/:id', protect, getPresentation);
router.put('/:id', protect, updatePresentation);
router.delete('/:id', protect, deletePresentation);

export default router;