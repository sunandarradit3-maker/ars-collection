import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import dotenv from 'dotenv';

// Load env variables
dotenv.config();

// Import routes
import authRoutes from './routes/auth.js';
import presentationRoutes from './routes/presentations.js';
import uploadRoutes from './routes/upload.js';
import aiRoutes from './routes/ai.js';
import stripeRoutes from './routes/stripe.js';

const app = express();

// Middlewares
app.use(cors({ origin: ['http://localhost:3000', process.env.NEXTAUTH_URL || ''], credentials: true }));
app.use(express.json({ limit: '50mb' }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/presentations', presentationRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/payment', stripeRoutes);

// Socket.IO setup
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

io.on('connection', (socket) => {
  socket.on('join', (presentationId: string) => {
    socket.join(presentationId);
  });
  socket.on('slides:update', (slides: any[]) => {
    // Broadcast updated slides to other clients in the room
    const rooms = Array.from(socket.rooms);
    rooms.forEach((room) => {
      if (room !== socket.id) {
        io.to(room).emit('slides:update', slides);
      }
    });
  });
});

// Connect to MongoDB and start server
const PORT = process.env.PORT || 4000;
mongoose
  .connect(process.env.MONGODB_URI || '')
  .then(() => {
    server.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Failed to connect to MongoDB', err);
  });