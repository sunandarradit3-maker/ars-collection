import { Schema, model, Document, Types } from 'mongoose';

export interface ISlide {
  _id: string;
  type: string;
  content: any;
  animation?: string;
  notes?: string;
}

export interface IPresentation extends Document {
  title: string;
  owner: Types.ObjectId;
  slides: ISlide[];
  collaborators?: Types.ObjectId[];
  createdAt: Date;
  updatedAt: Date;
}

const slideSchema = new Schema<ISlide>({
  _id: { type: String, required: true },
  type: { type: String, required: true },
  content: { type: Schema.Types.Mixed },
  animation: { type: String },
  notes: { type: String },
});

const presentationSchema = new Schema<IPresentation>(
  {
    title: { type: String, required: true },
    owner: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    slides: [slideSchema],
    collaborators: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  },
  { timestamps: true }
);

export default model<IPresentation>('Presentation', presentationSchema);