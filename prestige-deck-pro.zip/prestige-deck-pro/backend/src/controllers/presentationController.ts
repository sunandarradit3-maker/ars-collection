import { Request, Response } from 'express';
import Presentation from '../models/Presentation.js';
import { AuthRequest } from '../middleware/auth.js';

export const getPresentations = async (req: AuthRequest, res: Response) => {
  try {
    const presentations = await Presentation.find({ owner: req.userId });
    res.json(presentations);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to fetch presentations' });
  }
};

export const createPresentation = async (req: AuthRequest, res: Response) => {
  try {
    const { title } = req.body;
    const presentation = new Presentation({ title, owner: req.userId, slides: [] });
    await presentation.save();
    res.status(201).json(presentation);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to create presentation' });
  }
};

export const getPresentation = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const presentation = await Presentation.findById(id);
    if (!presentation || presentation.owner.toString() !== req.userId) {
      return res.status(404).json({ message: 'Presentation not found' });
    }
    res.json(presentation);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to fetch presentation' });
  }
};

export const updatePresentation = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { slides } = req.body;
    const presentation = await Presentation.findById(id);
    if (!presentation || presentation.owner.toString() !== req.userId) {
      return res.status(404).json({ message: 'Presentation not found' });
    }
    presentation.slides = slides;
    await presentation.save();
    res.json(presentation);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to update presentation' });
  }
};

export const deletePresentation = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const presentation = await Presentation.findById(id);
    if (!presentation || presentation.owner.toString() !== req.userId) {
      return res.status(404).json({ message: 'Presentation not found' });
    }
    await presentation.deleteOne();
    res.json({ message: 'Presentation deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to delete presentation' });
  }
};