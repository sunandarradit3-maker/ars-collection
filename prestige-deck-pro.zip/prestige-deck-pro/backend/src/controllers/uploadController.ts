import { Request, Response } from 'express';
import AWS from 'aws-sdk';
import { v4 as uuidv4 } from 'uuid';
import { AuthRequest } from '../middleware/auth.js';

const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
});

export const uploadMedia = async (req: AuthRequest, res: Response) => {
  try {
    const { file, fileName, contentType } = req.body;
    const buffer = Buffer.from(file, 'base64');
    const key = `${req.userId}/${uuidv4()}-${fileName}`;
    await s3
      .putObject({
        Bucket: process.env.AWS_S3_BUCKET || '',
        Key: key,
        Body: buffer,
        ContentType: contentType,
      })
      .promise();
    const url = `https://${process.env.AWS_S3_BUCKET}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;
    res.json({ url, key });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to upload media' });
  }
};