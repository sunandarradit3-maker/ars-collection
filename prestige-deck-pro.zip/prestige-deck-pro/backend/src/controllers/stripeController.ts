import { Request, Response } from 'express';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
});

// Map plan names to Stripe price IDs (replace with your actual price IDs)
const priceMap: Record<string, string> = {
  pro: 'price_pro',
  enterprise: 'price_enterprise',
};

export const createCheckoutSession = async (req: Request, res: Response) => {
  const { plan } = req.body;
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceMap[plan] || priceMap.pro,
          quantity: 1,
        },
      ],
      success_url: `${process.env.NEXTAUTH_URL}/dashboard?status=success`,
      cancel_url: `${process.env.NEXTAUTH_URL}/pricing?status=cancelled`,
    });
    res.json({ id: session.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to create Stripe session' });
  }
};