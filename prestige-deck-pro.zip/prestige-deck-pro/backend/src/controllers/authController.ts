import { Request, Response } from 'express';
import User, { IUser } from '../models/User.js';
import jwt from 'jsonwebtoken';

// Generate JWT token for a user
function generateToken(user: IUser) {
  return jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'secret', { expiresIn: '30d' });
}

// Register a new user
export async function register(req: Request, res: Response) {
  try {
    const { email, password, name } = req.body;
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: 'Email already registered' });
    const user = new User({ email, password, name });
    await user.save();
    const token = generateToken(user);
    res.json({ _id: user._id, email: user.email, name: user.name, token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Registration failed' });
  }
}

// Login user
export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });
    const isMatch = await user.comparePassword(password);
    if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });
    const token = generateToken(user);
    res.json({ _id: user._id, email: user.email, name: user.name, token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Login failed' });
  }
}