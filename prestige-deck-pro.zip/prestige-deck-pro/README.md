# PrestigeDeck Pro

**PrestigeDeck Pro** adalah sebuah platform presentasi modern yang menghadirkan kemewahan dan kecanggihan setara layanan seperti Pitch.com maupun Gamma AI. Proyek ini dibangun sebagai aplikasi full stack dengan arsitektur yang scalable dan performa tinggi. Repository ini berisi sumber kode untuk frontend, backend, skema basis data, berkas konfigurasi deployment, serta satu contoh presentasi bertema **“The Future of AI in Creative Industry”**.

## ✨ Fitur Utama

- **Editor WYSIWYG** dengan drag & drop dan panel properti, mendukung undo/redo tak terbatas, auto‑save setiap 2 detik, serta kolaborasi real‑time berbasis Socket IO.
- **Animasi & Transisi**: 50+ preset transisi, timeline animasi kustom, dan dukungan Lottie. Transisi slide disimpan sebagai bagian dari data presentasi.
- **Perpustakaan Template**: lebih dari 100 template premium dengan warna, tipografi, dan tata letak yang dapat diaplikasikan dengan sekali klik ke seluruh deck.
- **Integrasi AI** (stub/placeholder): generator outline slide dari topik, penataan ulang tata letak otomatis, pembuatan gambar hero menggunakan model generatif (DALL‑E 3), serta text‑to‑speech untuk catatan presenter. Fungsi AI dapat diaktifkan melalui API backend.
- **Mode Presenter**: teleprompter dengan auto‑scroll, timer, Q&A interaktif via QR code, polling live dengan chart real‑time, dan rekaman layar + webcam.
- **Ekspor & Berbagi**: ekspor ke PPT, PDF, HTML, MP4 (video), dan GIF. Bagikan presentasi melalui tautan khusus dengan proteksi password, tanggal kedaluwarsa, dan analitik pemirsa.
- **Perpustakaan Aset**: integrasi Unsplash & Pexels (memerlukan kunci API), perpustakaan ikon (>10 ribu ikon), alat bentuk & diagram, serta unggah video/audio ke AWS S3 lengkap dengan alat trimming.

## 🏗 Struktur Repository

```
prestige-deck-pro/
├── README.md           # Dokumentasi proyek ini
├── .env.example        # Contoh variabel lingkungan untuk frontend & backend
├── frontend/           # Aplikasi Next.js 14 + React 18 dengan TypeScript
│   ├── package.json
│   ├── tsconfig.json
│   ├── next.config.js
│   ├── postcss.config.js
│   ├── tailwind.config.ts
│   ├── src/
│   │   ├── app/        # Folder App Router (pages diatur sebagai route)
│   │   ├── components/ # Komponen UI (navbar, editor, dll)
│   │   ├── lib/        # Helpers: auth, fetchers, Zustand store, dll
│   │   ├── styles/     # Style global
│   │   └── data/       # Data demo (contoh presentasi)
├── backend/            # API server Node.js + Express + MongoDB + Socket.IO
│   ├── package.json
│   ├── tsconfig.json
│   ├── src/
│   │   ├── index.ts    # Entrypoint server
│   │   ├── config/
│   │   │   ├── mongo.ts
│   │   │   ├── aws.ts
│   │   │   └── stripe.ts
│   │   ├── models/     # Skema Mongoose
│   │   ├── routes/     # Route Express untuk API
│   │   ├── controllers/# Handler business logic
│   │   └── sockets/    # Konfigurasi real‑time (collaboration, polling, dll)
│   └── utils/
├── database/           # Skema basis data & seed
│   ├── schemas.ts
│   └── demoPresentation.json
├── deployment/         # Konfigurasi deployment (Vercel, Docker)
│   ├── vercel.json
│   └── Dockerfile
└── LICENSE
```

## 🚀 Cara Memulai

Repositori ini terdiri dari dua aplikasi yang berjalan terpisah: `frontend` (Next.js) dan `backend` (Express). Untuk menjalankan secara lokal, Anda perlu menyiapkan beberapa variabel lingkungan terlebih dulu. Contoh konfigurasi dapat ditemukan pada file `.env.example`.

1. **Kloning repositori dan instal dependensi**

   ```bash
   git clone https://example.com/prestige-deck-pro.git
   cd prestige-deck-pro

   # instal dependensi backend
   cd backend && npm install
   
   # instal dependensi frontend
   cd ../frontend && npm install
   ```

2. **Konfigurasikan variabel lingkungan**

   Salin `.env.example` menjadi `.env.local` di folder utama, lalu isi nilai seperti:

   ```env
   # Server
   PORT=4000
   MONGODB_URI=mongodb+srv://user:pass@cluster0.mongodb.net/prestige
   JWT_SECRET=supersecret

   # AWS S3
   AWS_ACCESS_KEY_ID=...
   AWS_SECRET_ACCESS_KEY=...
   AWS_REGION=ap-southeast-1
   AWS_S3_BUCKET=prestige-media

   # Stripe
   STRIPE_SECRET_KEY=sk_test_...
   STRIPE_PUBLISHABLE_KEY=pk_test_...

   # Google OAuth (NextAuth)
   GOOGLE_CLIENT_ID=...
   GOOGLE_CLIENT_SECRET=...

   # NextAuth
   NEXTAUTH_URL=http://localhost:3000
   NEXTAUTH_SECRET=your_nextauth_secret
   
   # Frontend base URL untuk API
   NEXT_PUBLIC_API_URL=http://localhost:4000/api
   NEXT_PUBLIC_WS_URL=http://localhost:4000
   ```

3. **Jalankan server backend**

   ```bash
   cd backend
   npm run dev
   ```

   Server Express akan berjalan pada `http://localhost:4000` dan menyediakan berbagai endpoint REST serta Socket IO untuk kolaborasi real‑time.

4. **Jalankan frontend**

   Buka terminal baru:

   ```bash
   cd frontend
   npm run dev
   ```

   Aplikasi Next.js akan tersedia pada `http://localhost:3000`.

5. **Deploy ke Vercel**

   - **Frontend**: Setelah mem‐push kode ke repository Git, Anda dapat menghubungkan repositori ke [Vercel](https://vercel.com). Pastikan menambahkan environment variables pada pengaturan project di Vercel sesuai dengan file `.env.example`.
   - **Backend**: Anda dapat menjalankan backend di layanan seperti Vercel Serverless Functions, AWS Lambda, atau menjalankan server Node.js tradisional di VPS. File `deployment/vercel.json` menunjukkan contoh rewrite agar permintaan API diarahkan ke server yang sesuai.

6. **Struktur Basis Data & Seed**

   Skema Mongoose untuk koleksi seperti `User`, `Presentation`, dan `Slide` berada di folder `backend/src/models`. Contoh data presentasi demo dapat ditemukan pada `database/demoPresentation.json`. Jalankan script seeding (Anda dapat menulis script sendiri) untuk memasukkan data tersebut ke MongoDB.

## 🧪 API Documentation

Backend menyediakan endpoint REST di bawah prefiks `/api`. Beberapa endpoint utama:

- `POST /api/auth/register` – mendaftarkan pengguna baru.
- `POST /api/auth/login` – autentikasi dengan email/password.
- `GET /api/presentations` – mengambil daftar presentasi untuk user yang masuk.
- `POST /api/presentations` – membuat presentasi baru.
- `GET /api/presentations/:id` – mengambil detail presentasi, termasuk slide, animasi, dan versi.
- `PUT /api/presentations/:id` – memperbarui presentasi.
- `DELETE /api/presentations/:id` – menghapus presentasi.
- `POST /api/upload` – mengunggah media (gambar/audio/video) ke AWS S3.
- `POST /api/ai/outline` – (stub) menghasilkan outline slide dari topik.
- `POST /api/ai/design` – (stub) menyesuaikan tata letak & estetika berdasarkan konten.

Untuk dokumentasi lengkap termasuk parameter request dan response schema, silakan lihat file `backend/src/routes` dan `backend/src/controllers`.

## 🧠 Demo Presentasi: *“The Future of AI in Creative Industry”*

Untuk memberikan gambaran fungsi aplikasi, folder `database/demoPresentation.json` menyertakan contoh data 15 slide bertema *“The Future of AI in Creative Industry”*. Setiap slide memiliki jenis layout berbeda seperti judul, timeline, galeri gambar, statistik, dan kutipan inspiratif. Animasi transisi seperti partikel dan morphing disimpan dalam properti slide.

Anda dapat memuat presentasi contoh tersebut dengan mengimpor file JSON ke MongoDB (atau menyalinnya ke koleksi `presentations`) agar langsung tersedia di dashboard aplikasi.

## 🤝 Kontribusi

Proyek ini dikembangkan sebagai contoh untuk klien Fortune 500. Kontribusi sangat disambut untuk memperbaiki bug, meningkatkan fitur, atau menambah dokumentasi. Silakan buat issue atau pull request jika Anda menemukan sesuatu yang perlu diperbaiki.

## 📄 Lisensi

Kode sumber proyek ini dilisensikan di bawah MIT License. Lihat file `LICENSE` untuk detail lebih lanjut.