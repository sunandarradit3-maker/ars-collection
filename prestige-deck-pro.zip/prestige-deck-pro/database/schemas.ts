// This file defines TypeScript interfaces for database documents.

export interface Slide {
  _id: string;
  type: 'title' | 'content' | 'gallery' | 'timeline' | 'stats' | 'quote';
  content: any;
  animation?: string;
  notes?: string;
}

export interface Presentation {
  _id: string;
  title: string;
  owner: string;
  slides: Slide[];
  collaborators?: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface User {
  _id: string;
  email: string;
  password: string;
  name: string;
  createdAt?: string;
  updatedAt?: string;
}