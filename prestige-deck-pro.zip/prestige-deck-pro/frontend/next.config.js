/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    appDir: true,
    serverActions: true
  },
  images: {
    domains: [
      'images.unsplash.com',
      'images.pexels.com',
      'localhost',
      process.env.NEXT_PUBLIC_S3_BUCKET || ''
    ]
  }
};

module.exports = nextConfig;