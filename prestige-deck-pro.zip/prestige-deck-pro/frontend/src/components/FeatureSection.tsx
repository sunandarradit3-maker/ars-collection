import { MotionValue, useAnimation, motion } from 'framer-motion';

const features = [
  {
    title: 'Real‑time Collaboration',
    description: 'Work together on your slides with live cursors and unlimited history.',
    icon: '🤝',
  },
  {
    title: 'AI‑Assisted Design',
    description: 'Generate outlines, layouts and images with built‑in AI tools.',
    icon: '✨',
  },
  {
    title: 'Premium Templates',
    description: 'Choose from an ever‑growing library of corporate and creative templates.',
    icon: '📦',
  },
];

export default function FeatureSection() {
  return (
    <section className="py-16 bg-background-light">
      <div className="container mx-auto px-6 md:px-12">
        <h2 className="text-3xl md:text-4xl font-serif text-primary mb-8 text-center">
          Why PrestigeDeck?
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="p-6 bg-background rounded-lg border border-gray-700 hover:border-primary transition-colors"
            >
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-serif mb-2 text-primary">{feature.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}