"use client";
import { useEditorStore } from '@/store/editorStore';
import React from 'react';

export default function SlideCanvas() {
  const { slides, selectedSlideId, updateSlide } = useEditorStore();
  const slide = slides.find((s) => s._id === selectedSlideId);
  if (!slide) {
    return <div className="flex-1 flex items-center justify-center text-gray-500">Select a slide to edit</div>;
  }
  const handleInput = (e: React.FormEvent<HTMLDivElement>) => {
    const newText = e.currentTarget.textContent || '';
    updateSlide(slide._id, { content: { ...slide.content, text: newText } });
  };
  return (
    <div className="flex-1 p-8 overflow-auto">
      <div
        className="min-h-[400px] bg-background-light rounded-lg p-6 border border-gray-700 focus:outline-none"
        contentEditable
        suppressContentEditableWarning
        onInput={handleInput}
      >
        {slide.content?.text}
      </div>
    </div>
  );
}