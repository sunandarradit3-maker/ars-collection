"use client";
import { useEffect } from 'react';
import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';
import { useEditorStore } from '@/store/editorStore';
import SlideCanvas from './SlideCanvas';
import PropertiesPanel from './PropertiesPanel';
import { v4 as uuidv4 } from 'uuid';
import { io } from 'socket.io-client';
import { useMutation } from '@tanstack/react-query';
import { updatePresentation } from '@/lib/api';

interface EditorProps {
  presentationId: string;
  initialSlides: any[];
}

// Initialise socket outside component to avoid re‑creating on each render
const socket = io(typeof window !== 'undefined' ? (process.env.NEXT_PUBLIC_WS_URL || '') : '', {
  autoConnect: false,
});

export default function Editor({ presentationId, initialSlides }: EditorProps) {
  const {
    slides,
    setSlides,
    addSlide,
    updateSlide,
    removeSlide,
    selectSlide,
    selectedSlideId,
  } = useEditorStore();

  // load initial slides once
  useEffect(() => {
    setSlides(initialSlides);
  }, [initialSlides, setSlides]);

  // Setup socket connection for collaboration
  useEffect(() => {
    socket.connect();
    socket.emit('join', presentationId);
    socket.on('slides:update', (remoteSlides: any[]) => {
      setSlides(remoteSlides);
    });
    return () => {
      socket.off('slides:update');
      socket.disconnect();
    };
  }, [presentationId, setSlides]);

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    const newSlides = Array.from(slides);
    const [removed] = newSlides.splice(result.source.index, 1);
    newSlides.splice(result.destination.index, 0, removed);
    setSlides(newSlides);
    socket.emit('slides:update', newSlides);
  };

  // Auto save every 2 seconds
  const mutation = useMutation({
    mutationFn: updatePresentation,
  });
  useEffect(() => {
    const interval = setInterval(() => {
      if (slides && slides.length) {
        mutation.mutate({ id: presentationId, slides });
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [slides, mutation, presentationId]);

  const addNewSlide = () => {
    const id = uuidv4();
    const newSlide = {
      _id: id,
      type: 'content',
      content: { text: 'New Slide' },
    };
    addSlide(newSlide);
    selectSlide(id);
    socket.emit('slides:update', [...slides, newSlide]);
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] overflow-hidden">
      <aside className="w-1/5 bg-background-light p-2 overflow-y-auto">
        <button onClick={addNewSlide} className="w-full mb-2 px-2 py-1 bg-primary text-background rounded-md text-sm">
          + Slide
        </button>
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="slides">
            {(provided) => (
              <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-2">
                {slides.map((slide, index) => (
                  <Draggable draggableId={slide._id} index={index} key={slide._id}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className={`p-2 rounded-md cursor-pointer text-sm truncate ${
                          selectedSlideId === slide._id ? 'bg-primary text-background' : 'bg-background-light border border-gray-700'
                        }`}
                        onClick={() => selectSlide(slide._id)}
                      >
                        {slide.content?.title || slide.content?.text || `Slide ${index + 1}`}
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </aside>
      <main className="flex-1 flex flex-col overflow-hidden">
        <SlideCanvas />
      </main>
      <div className="w-1/4">
        <PropertiesPanel />
      </div>
    </div>
  );
}