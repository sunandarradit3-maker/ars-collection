"use client";
import { useEditorStore } from '@/store/editorStore';
import React from 'react';

export default function PropertiesPanel() {
  const { slides, selectedSlideId, updateSlide } = useEditorStore();
  const slide = slides.find((s) => s._id === selectedSlideId);
  if (!slide) return null;
  const handleTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateSlide(slide._id, { type: e.target.value as any });
  };
  return (
    <div className="p-4 bg-background-light h-full border-l border-gray-700 overflow-y-auto">
      <h3 className="font-serif text-lg mb-3 text-primary">Properties</h3>
      <label className="block text-sm mb-1">Slide Type</label>
      <select
        value={slide.type}
        onChange={handleTypeChange}
        className="w-full bg-background border border-gray-600 rounded-md p-2 mb-4"
      >
        <option value="title">Title</option>
        <option value="content">Content</option>
        <option value="timeline">Timeline</option>
        <option value="gallery">Gallery</option>
        <option value="stats">Stats</option>
        <option value="quote">Quote</option>
      </select>
      {/* Additional properties could be added here, such as background color, images, etc. */}
    </div>
  );
}