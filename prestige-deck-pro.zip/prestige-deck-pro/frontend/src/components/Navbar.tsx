"use client";
import Link from 'next/link';
import { useSession, signIn, signOut } from 'next-auth/react';

export default function Navbar() {
  const { data: session } = useSession();

  return (
    <nav className="flex items-center justify-between px-6 py-4 bg-background-light border-b border-gray-700 z-10">
      <Link href="/" className="font-serif text-2xl text-primary">PrestigeDeck</Link>
      <div className="flex items-center gap-4 text-sm">
        <Link href="/templates" className="hover:text-primary transition-colors">Templates</Link>
        <Link href="/pricing" className="hover:text-primary transition-colors">Pricing</Link>
        {session ? (
          <>
            <Link href="/dashboard" className="hover:text-primary transition-colors">Dashboard</Link>
            <button
              onClick={() => signOut()}
              className="px-4 py-2 rounded-md bg-primary text-background font-medium"
            >
              Sign out
            </button>
          </>
        ) : (
          <button
            onClick={() => signIn('google')}
            className="px-4 py-2 rounded-md bg-primary text-background font-medium"
          >
            Sign in
          </button>
        )}
      </div>
    </nav>
  );
}