import { create } from 'zustand';
import { Slide } from '@/types';

type EditorState = {
  slides: Slide[];
  selectedSlideId: string | null;
  history: Slide[][];
  historyIndex: number;
  setSlides: (slides: Slide[]) => void;
  addSlide: (slide: Slide) => void;
  updateSlide: (id: string, updates: Partial<Slide>) => void;
  removeSlide: (id: string) => void;
  selectSlide: (id: string) => void;
  undo: () => void;
  redo: () => void;
};

export const useEditorStore = create<EditorState>((set, get) => ({
  slides: [],
  selectedSlideId: null,
  history: [],
  historyIndex: -1,
  setSlides: (slides) => set(() => ({ slides })),
  addSlide: (slide) => {
    const { slides, history, historyIndex } = get();
    const newSlides = [...slides, slide];
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newSlides);
    set({ slides: newSlides, history: newHistory, historyIndex: historyIndex + 1 });
  },
  updateSlide: (id, updates) => {
    const { slides, history, historyIndex } = get();
    const newSlides = slides.map((s) => (s._id === id ? { ...s, ...updates } : s));
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newSlides);
    set({ slides: newSlides, history: newHistory, historyIndex: historyIndex + 1 });
  },
  removeSlide: (id) => {
    const { slides, history, historyIndex } = get();
    const newSlides = slides.filter((s) => s._id !== id);
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newSlides);
    set({ slides: newSlides, history: newHistory, historyIndex: historyIndex + 1 });
  },
  selectSlide: (id) => set({ selectedSlideId: id }),
  undo: () => {
    const { history, historyIndex } = get();
    if (historyIndex > 0) {
      set({ historyIndex: historyIndex - 1, slides: history[historyIndex - 1] });
    }
  },
  redo: () => {
    const { history, historyIndex } = get();
    if (historyIndex < history.length - 1) {
      set({ historyIndex: historyIndex + 1, slides: history[historyIndex + 1] });
    }
  },
}));