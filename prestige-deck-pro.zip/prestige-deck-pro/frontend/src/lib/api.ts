import { Presentation, Slide } from '@/types';

// Base helper to handle fetch with credentials
async function fetchWithCredentials(url: string, options: RequestInit = {}) {
  const res = await fetch(url, { ...options, credentials: 'include' });
  if (!res.ok) {
    throw new Error(await res.text());
  }
  return res.json();
}

export async function getPresentations(): Promise<Presentation[]> {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/presentations`;
  return fetchWithCredentials(url);
}

export async function getPresentation(id: string): Promise<Presentation> {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/presentations/${id}`;
  return fetchWithCredentials(url);
}

export async function createPresentation(title: string): Promise<Presentation> {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/presentations`;
  return fetchWithCredentials(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title }),
  });
}

export async function updatePresentation({ id, slides }: { id: string; slides: Slide[] }): Promise<Presentation> {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/presentations/${id}`;
  return fetchWithCredentials(url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ slides }),
  });
}