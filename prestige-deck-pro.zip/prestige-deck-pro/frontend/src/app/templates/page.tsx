export default function TemplatesPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-serif text-primary mb-4">Template Gallery</h1>
      <p className="text-gray-400 mb-8">
        Coming soon: over 100 premium templates curated for corporate, startup, and creative presentations.
      </p>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {/* Placeholder cards */}
        {Array.from({ length: 8 }).map((_, idx) => (
          <div
            key={idx}
            className="bg-background-light border border-gray-700 rounded-lg h-40 flex items-center justify-center text-gray-600"
          >
            Preview
          </div>
        ))}
      </div>
    </div>
  );
}