"use client";
import { signIn } from 'next-auth/react';

export default function SignInPage() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center p-8">
      <h1 className="text-3xl font-serif text-primary mb-4">Sign In</h1>
      <button
        onClick={() => signIn('google')}
        className="px-6 py-3 bg-primary text-background rounded-md font-medium"
      >
        Continue with Google
      </button>
    </div>
  );
}