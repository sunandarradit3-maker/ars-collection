export default function PricingPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-serif text-primary mb-8">Pricing</h1>
      <div className="grid md:grid-cols-3 gap-8">
        {/* Starter Plan */}
        <div className="p-6 bg-background-light border border-gray-700 rounded-lg text-center">
          <h2 className="font-serif text-2xl mb-2 text-primary">Starter</h2>
          <p className="text-4xl font-bold mb-4 text-primary">Free</p>
          <ul className="text-left space-y-2 mb-6 text-sm text-gray-400">
            <li>✅ Unlimited presentations</li>
            <li>✅ Basic templates</li>
            <li>✅ 5 collaborators</li>
            <li>❌ AI features</li>
          </ul>
          <button className="px-6 py-2 bg-primary text-background rounded-md">Get Started</button>
        </div>
        {/* Pro Plan */}
        <div className="p-6 bg-background-light border border-primary rounded-lg text-center">
          <h2 className="font-serif text-2xl mb-2 text-primary">Pro</h2>
          <p className="text-4xl font-bold mb-4 text-primary">$12<span className="text-xl">/mo</span></p>
          <ul className="text-left space-y-2 mb-6 text-sm text-gray-400">
            <li>✅ Everything in Starter</li>
            <li>✅ Premium templates</li>
            <li>✅ AI assistant & design</li>
            <li>✅ 20 collaborators</li>
            <li>✅ Priority support</li>
          </ul>
          <button className="px-6 py-2 bg-primary text-background rounded-md">Upgrade</button>
        </div>
        {/* Enterprise Plan */}
        <div className="p-6 bg-background-light border border-gray-700 rounded-lg text-center">
          <h2 className="font-serif text-2xl mb-2 text-primary">Enterprise</h2>
          <p className="text-4xl font-bold mb-4 text-primary">Contact us</p>
          <ul className="text-left space-y-2 mb-6 text-sm text-gray-400">
            <li>✅ Everything in Pro</li>
            <li>✅ Unlimited collaborators</li>
            <li>✅ Dedicated account manager</li>
            <li>✅ Custom integrations</li>
          </ul>
          <button className="px-6 py-2 bg-primary text-background rounded-md">Contact Sales</button>
        </div>
      </div>
    </div>
  );
}