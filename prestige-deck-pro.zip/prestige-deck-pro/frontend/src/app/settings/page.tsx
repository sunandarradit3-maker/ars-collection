"use client";
import { useSession } from 'next-auth/react';
import { useState } from 'react';

export default function SettingsPage() {
  const { data: session } = useSession();
  const [name, setName] = useState(session?.user?.name || '');
  const [email] = useState(session?.user?.email || '');
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: call backend to update profile
    alert('Profile updated');
  };
  if (!session) return <div className="p-8">Please sign in to view your settings.</div>;
  return (
    <div className="p-8 max-w-xl mx-auto">
      <h1 className="text-3xl font-serif text-primary mb-6">Settings</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm mb-1">Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-background-light border border-gray-600 rounded-md p-2"
          />
        </div>
        <div>
          <label className="block text-sm mb-1">Email</label>
          <input
            type="email"
            value={email}
            disabled
            className="w-full bg-background-light border border-gray-600 rounded-md p-2 text-gray-500"
          />
        </div>
        <button type="submit" className="px-4 py-2 bg-primary text-background rounded-md">Save</button>
      </form>
    </div>
  );
}