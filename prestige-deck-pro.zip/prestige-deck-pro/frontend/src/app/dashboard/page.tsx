"use client";
import { useSession } from 'next-auth/react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Link from 'next/link';
import { getPresentations, createPresentation } from '@/lib/api';

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery(['presentations'], getPresentations, { enabled: !!session });
  const mutation = useMutation({
    mutationFn: (title: string) => createPresentation(title),
    onSuccess: () => queryClient.invalidateQueries(['presentations']),
  });

  const handleCreate = () => {
    const title = prompt('Enter presentation title');
    if (title) {
      mutation.mutate(title);
    }
  };

  if (status === 'loading') {
    return <div className="p-8">Loading…</div>;
  }
  if (!session) {
    return (
      <div className="p-8">
        <p>Please sign in to view your dashboard.</p>
      </div>
    );
  }
  return (
    <div className="p-8">
      <h1 className="text-3xl font-serif text-primary mb-4">Your Presentations</h1>
      <button
        onClick={handleCreate}
        className="mb-6 px-4 py-2 bg-primary text-background rounded-md text-sm"
      >
        + New Deck
      </button>
      {isLoading ? (
        <p>Loading…</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {data && data.length > 0 ? (
            data.map((p) => (
              <Link
                key={p._id}
                href={`/editor/${p._id}`}
                className="p-4 bg-background-light rounded-lg border border-gray-700 hover:border-primary transition-colors"
              >
                <h2 className="font-serif text-xl mb-1 text-primary truncate">{p.title}</h2>
                <p className="text-xs text-gray-400">{p.slides?.length || 0} slides</p>
              </Link>
            ))
          ) : (
            <p>You have no presentations yet.</p>
          )}
        </div>
      )}
    </div>
  );
}