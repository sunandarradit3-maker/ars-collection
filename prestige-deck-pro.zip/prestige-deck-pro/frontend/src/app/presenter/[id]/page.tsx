"use client";
import { useEffect, useState, useRef } from 'react';
import { getPresentation } from '@/lib/api';

interface Props {
  params: { id: string };
}

export default function PresenterPage({ params }: Props) {
  const [presentation, setPresentation] = useState<any>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    getPresentation(params.id).then(setPresentation);
  }, [params.id]);

  useEffect(() => {
    timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const nextSlide = () => {
    setCurrentIndex((idx) => Math.min((presentation?.slides.length || 1) - 1, idx + 1));
  };
  const prevSlide = () => {
    setCurrentIndex((idx) => Math.max(0, idx - 1));
  };
  if (!presentation) {
    return <div className="p-8">Loading…</div>;
  }
  const slide = presentation.slides[currentIndex];
  const minutes = Math.floor(elapsed / 60)
    .toString()
    .padStart(2, '0');
  const seconds = (elapsed % 60).toString().padStart(2, '0');
  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] p-4">
      <div className="flex-1 overflow-auto mb-4">
        <h2 className="font-serif text-2xl text-primary mb-2">{presentation.title}</h2>
        <div className="text-lg leading-relaxed whitespace-pre-wrap" style={{ scrollBehavior: 'smooth' }}>
          {slide.content?.text}
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <button onClick={prevSlide} className="px-4 py-2 bg-primary text-background rounded-md">Prev</button>
          <button onClick={nextSlide} className="px-4 py-2 bg-primary text-background rounded-md">Next</button>
        </div>
        <div className="text-primary font-mono">{minutes}:{seconds}</div>
      </div>
    </div>
  );
}