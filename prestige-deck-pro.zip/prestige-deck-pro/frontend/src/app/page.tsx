import { Suspense } from 'react';
import FeatureSection from '../components/FeatureSection';

export default function Home() {
  return (
    <main>
      <section className="min-h-[80vh] flex flex-col justify-center items-center text-center relative overflow-hidden px-4 pt-16">
        {/* Aurora background */}
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-purple-800 via-pink-700 to-orange-600 animate-pulse opacity-40" />
        <h1 className="text-5xl md:text-7xl font-serif font-bold text-primary drop-shadow-lg">
          PrestigeDeck Pro
        </h1>
        <p className="mt-4 text-xl md:text-2xl max-w-2xl text-gray-300">
          Elevate your presentations with AI‑powered design, real‑time collaboration, and luxury aesthetics.
        </p>
        <div className="mt-8 flex gap-4 flex-wrap justify-center">
          <a
            href="/dashboard"
            className="px-8 py-3 rounded-xl bg-primary text-background font-medium hover:bg-primary-dark transition-colors"
          >
            Get Started
          </a>
          <a
            href="/pricing"
            className="px-8 py-3 rounded-xl border border-primary text-primary hover:bg-primary hover:text-background transition-colors"
          >
            Pricing
          </a>
        </div>
      </section>
      <Suspense>
        <FeatureSection />
      </Suspense>
    </main>
  );
}