import '../styles/globals.css';
import type { ReactNode } from 'react';
import { Inter, Playfair_Display } from 'next/font/google';
import Providers from '../components/Providers';
import Navbar from '../components/Navbar';
import CustomCursor from '../components/CustomCursor';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' });

export const metadata = {
  title: 'PrestigeDeck Pro',
  description: 'Super premium presentation platform with AI and real-time collaboration',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} ${playfair.variable} bg-background text-white relative`}> 
        <Providers>
          <Navbar />
          {children}
          <CustomCursor />
        </Providers>
      </body>
    </html>
  );
}