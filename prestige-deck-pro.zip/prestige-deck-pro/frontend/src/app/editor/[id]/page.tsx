import { getPresentation } from '@/lib/api';
import Editor from '@/components/editor/Editor';

interface Props {
  params: { id: string };
}

export default async function EditorPage({ params }: Props) {
  const presentation = await getPresentation(params.id);
  return (
    <div className="h-[calc(100vh-4rem)]">
      {/* Editor component is client side only */}
      <Editor presentationId={presentation._id} initialSlides={presentation.slides} />
    </div>
  );
}