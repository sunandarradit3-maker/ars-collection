export interface Slide {
  _id: string;
  type: 'title' | 'content' | 'gallery' | 'timeline' | 'stats' | 'quote';
  content: any;
  animation?: string;
  notes?: string;
}

export interface Presentation {
  _id: string;
  title: string;
  slides: Slide[];
  createdAt?: string;
  updatedAt?: string;
}