import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Ars Collection - Premium Digital Tools',
  description: 'Tools Shunter, AI Prompts, Ebooks, Digital Products',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className={`${inter.className} bg-black text-white`}>
        {children}
      </body>
    </html>
  );
}